@echo off
setlocal
title ComfyUI-Easy-Install-AMD - Toggle Triton
cd /d "%~dp0..\..\"
"python_embeded\python.exe" amd\windows_tools.py triton
if errorlevel 1 exit /b 1
if "%~1"=="" pause
