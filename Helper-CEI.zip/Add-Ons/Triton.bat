@echo off
cd /d "%~dp0.."
".\python_embeded\python.exe" amd\maintenance.py triton
if errorlevel 1 (
    echo Triton installation failed.
    pause
    exit /b 1
)
echo Triton installed successfully.
pause
